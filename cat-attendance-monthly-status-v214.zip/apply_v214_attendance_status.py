
from pathlib import Path
import sys
import subprocess

main_path = Path("src/main.js")
style_path = Path("src/style.css")

if not main_path.exists() or not style_path.exists():
    sys.exit("안전 중단: src/main.js 또는 src/style.css를 찾지 못했습니다.")

text = main_path.read_text(encoding="utf-8")
style = style_path.read_text(encoding="utf-8")

MARKER = "/* v214 개인별 월간 근태 현황 */"
if MARKER in text and MARKER in style:
    print("v214 근태현황이 이미 적용되어 있습니다.")
    sys.exit(0)

def replace_once(source, old, new, label):
    if old not in source:
        sys.exit(f"안전 중단: {label} 위치를 찾지 못했습니다. 현재 버전을 확인해 주세요.")
    return source.replace(old, new, 1)

text = replace_once(
    text,
    '''const APP_PAGE_TITLES = {
  attendance: "근태관리",
  salary: "급여내역",''',
    '''const APP_PAGE_TITLES = {
  attendance: "근태관리",
  status: "근태현황",
  salary: "급여내역",''',
    "APP_PAGE_TITLES",
)

attendance_menu = '''          <button
            class="navigation-item active"
            type="button"
            data-app-navigation="attendance"
            aria-current="page"
          >
            <span class="navigation-icon">▦</span>
            <span>근태관리</span>
          </button>
'''
status_menu = attendance_menu + '''          <button
            class="navigation-item"
            type="button"
            data-app-navigation="status"
          >
            <span class="navigation-icon attendance-status-nav-icon">표</span>
            <span>근태현황</span>
          </button>
'''
text = replace_once(text, attendance_menu, status_menu, "근태관리 메뉴")

salary_page_marker = '''      <section
        class="app-page"
        data-app-page="salary"
        aria-label="급여내역"
        hidden
      >'''
status_page = '''      <section
        class="app-page attendance-status-page"
        data-app-page="status"
        aria-label="근태현황"
        hidden
      >
        <section class="attendance-status-card">
          <div class="attendance-status-report-title">
            <strong>개인별 월간 근태 현황</strong>
            <span id="attendanceStatusPeriod"></span>
          </div>

          <div class="attendance-status-toolbar">
            <button
              id="attendanceStatusPreviousMonth"
              class="attendance-status-month-button"
              type="button"
              aria-label="이전 달"
            >‹</button>
            <strong id="attendanceStatusMonthTitle"></strong>
            <button
              id="attendanceStatusNextMonth"
              class="attendance-status-month-button"
              type="button"
              aria-label="다음 달"
            >›</button>
          </div>

          <div
            id="attendanceStatusTableWrap"
            class="attendance-status-table-wrap"
            aria-label="개인별 월간 근태 현황 표"
          ></div>

          <div
            id="attendanceStatusFooter"
            class="attendance-status-footer"
          ></div>
        </section>
      </section>

''' + salary_page_marker
text = replace_once(text, salary_page_marker, status_page, "급여내역 페이지")

text = replace_once(
    text,
    '''let currentAppPage = "attendance";''',
    '''let currentAppPage = "attendance";
let attendanceStatusMonth = new Date(currentMonth);''',
    "currentAppPage",
)

dom_anchor = '''const appNavigationButtons = [
  ...document.querySelectorAll("[data-app-navigation]"),
];
'''
dom_block = dom_anchor + '''const attendanceStatusPreviousMonth = document.querySelector(
  "#attendanceStatusPreviousMonth",
);
const attendanceStatusNextMonth = document.querySelector(
  "#attendanceStatusNextMonth",
);
const attendanceStatusMonthTitle = document.querySelector(
  "#attendanceStatusMonthTitle",
);
const attendanceStatusPeriod = document.querySelector(
  "#attendanceStatusPeriod",
);
const attendanceStatusTableWrap = document.querySelector(
  "#attendanceStatusTableWrap",
);
const attendanceStatusFooter = document.querySelector(
  "#attendanceStatusFooter",
);
'''
text = replace_once(text, dom_anchor, dom_block, "appNavigationButtons")

nav_listener_anchor = '''appNavigationButtons.forEach((button) => {
  button.addEventListener("click", () => {
    setAppPage(button.dataset.appNavigation);
  });
});
'''
nav_listener_block = nav_listener_anchor + '''
attendanceStatusPreviousMonth?.addEventListener("click", () => {
  attendanceStatusMonth = new Date(
    attendanceStatusMonth.getFullYear(),
    attendanceStatusMonth.getMonth() - 1,
    1,
  );
  renderAttendanceStatus();
});

attendanceStatusNextMonth?.addEventListener("click", () => {
  attendanceStatusMonth = new Date(
    attendanceStatusMonth.getFullYear(),
    attendanceStatusMonth.getMonth() + 1,
    1,
  );
  renderAttendanceStatus();
});
'''
text = replace_once(text, nav_listener_anchor, nav_listener_block, "페이지 네비게이션 이벤트")

set_page_anchor = '''  closeAnnualLeaveYearPicker();
  if (pageId === "salary") {'''
set_page_block = '''  closeAnnualLeaveYearPicker();
  if (pageId === "status") {
    renderAttendanceStatus();
  }
  if (pageId === "salary") {'''
text = replace_once(text, set_page_anchor, set_page_block, "setAppPage")

render_anchor = '''function render() {
  renderCalendar();
  syncWeeklyDateRangeInputs();'''
render_block = '''function render() {
  renderCalendar();
  renderAttendanceStatus();
  syncWeeklyDateRangeInputs();'''
text = replace_once(text, render_anchor, render_block, "render 함수")

render_calendar_anchor = '''function renderCalendar() {
  renderCalendarWeekdayHeaders();'''
status_logic = r'''/* v214 개인별 월간 근태 현황 */
const ATTENDANCE_STATUS_ROWS = [
  { key: "clockIn", label: "출근", total: false },
  { key: "clockOut", label: "퇴근", total: false },
  { key: "late", label: "지각", total: true },
  { key: "earlyLeave", label: "조퇴", total: true },
  { key: "outing", label: "외출", total: true },
  { key: "absence", label: "결근", total: true },
  { key: "normal", label: "정상", total: true },
  { key: "overtime1", label: "연장1", total: true },
  { key: "overtime2", label: "연장2", total: true },
  { key: "night", label: "심야", total: true },
  { key: "overnight", label: "철야", total: true },
  { key: "holiday", label: "휴일", total: true },
  { key: "shutdown", label: "휴업", total: false },
];

function getAttendanceStatusValues(workRecord) {
  const workType = getWorkType(workRecord);
  if (!workType) {
    return {};
  }

  switch (workType.id) {
    case "day":
      return { clockIn: "0800", clockOut: "1700", normal: 8 };
    case "dayOvertime":
      return {
        clockIn: "0800",
        clockOut: "2000",
        normal: 8,
        overtime2: 2.5,
      };
    case "dayHoliday":
      return { clockIn: "0800", clockOut: "1700", holiday: 8 };
    case "dayHolidayOvertime":
      return {
        clockIn: "0800",
        clockOut: "2000",
        overtime2: 2.5,
        holiday: 8,
      };
    case "night":
      return {
        clockIn: "2000",
        clockOut: "0500",
        normal: 8,
        night: 6,
      };
    case "nightOvertime":
      return {
        clockIn: "2000",
        clockOut: "0800",
        normal: 8,
        overtime1: 2,
        night: 7,
        overnight: 1,
      };
    case "nightHoliday":
      return {
        clockIn: "2000",
        clockOut: "0500",
        night: 6,
        holiday: 8,
      };
    case "nightHolidayOvertime":
      return {
        clockIn: "2000",
        clockOut: "0800",
        overtime1: 2,
        night: 6,
        overnight: 1,
        holiday: 8,
      };
    case "earlyLeave":
      return { earlyLeave: 4 };
    case "annualLeave":
      return { shutdown: "연차" };
    case "halfAnnualLeave":
      return { shutdown: "반차" };
    default:
      return {};
  }
}

function formatAttendanceStatusValue(value) {
  if (value === null || value === undefined || value === "") {
    return "";
  }

  if (typeof value === "number") {
    return Number.isInteger(value) ? String(value) : String(value);
  }

  return escapeHtml(value);
}

function getAttendanceStatusRowTotal(rowKey, valuesByDay) {
  const values = valuesByDay
    .map((dayValues) => dayValues[rowKey])
    .filter((value) => typeof value === "number");

  if (!values.length) {
    return "";
  }

  const total = values.reduce((sum, value) => sum + value, 0);
  return Number.isInteger(total) ? String(total) : String(total);
}

function renderAttendanceStatus() {
  if (
    !attendanceStatusTableWrap ||
    !attendanceStatusMonthTitle ||
    !attendanceStatusPeriod ||
    !attendanceStatusFooter
  ) {
    return;
  }

  const year = attendanceStatusMonth.getFullYear();
  const month = attendanceStatusMonth.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthText = String(month + 1).padStart(2, "0");

  attendanceStatusMonthTitle.textContent = `${year}년 ${month + 1}월`;
  attendanceStatusPeriod.textContent = `( ${year}년 ${monthText}월 )`;

  const valuesByDay = Array.from({ length: 31 }, (_, index) => {
    const day = index + 1;
    if (day > daysInMonth) {
      return {};
    }

    const dateKey = createDateKey(year, month, day);
    return getAttendanceStatusValues(records[dateKey]);
  });

  const dayHeaders = Array.from({ length: 31 }, (_, index) => {
    const day = index + 1;
    const valid = day <= daysInMonth;
    return `<th class="${valid ? "" : "is-outside"}">${day}</th>`;
  }).join("");

  const weekdayHeaders = Array.from({ length: 31 }, (_, index) => {
    const day = index + 1;
    if (day > daysInMonth) {
      return '<th class="is-outside"></th>';
    }

    const date = new Date(year, month, day);
    const weekdayIndex = date.getDay();
    const weekdayText = ["일", "월", "화", "수", "목", "금", "토"][weekdayIndex];
    const weekdayClass =
      weekdayIndex === 0
        ? "is-sunday"
        : weekdayIndex === 6
          ? "is-saturday"
          : "";

    return `<th class="${weekdayClass}">${weekdayText}</th>`;
  }).join("");

  const rows = ATTENDANCE_STATUS_ROWS.map((row) => {
    const total = row.total
      ? getAttendanceStatusRowTotal(row.key, valuesByDay)
      : "";

    const cells = valuesByDay
      .map((dayValues, index) => {
        const outside = index + 1 > daysInMonth;
        const value = outside
          ? ""
          : formatAttendanceStatusValue(dayValues[row.key]);
        return `<td class="${outside ? "is-outside" : ""}">${value}</td>`;
      })
      .join("");

    return `
      <tr>
        <th class="attendance-status-row-label">${row.label}</th>
        <td class="attendance-status-total">${total}</td>
        ${cells}
      </tr>
    `;
  }).join("");

  attendanceStatusTableWrap.innerHTML = `
    <table class="attendance-status-table">
      <thead>
        <tr>
          <th rowspan="2" class="attendance-status-corner">구분</th>
          <th rowspan="2" class="attendance-status-sum-head">합계</th>
          ${dayHeaders}
        </tr>
        <tr>${weekdayHeaders}</tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `;

  const recordedDays = valuesByDay.filter(
    (dayValues) => Object.keys(dayValues).length > 0,
  ).length;
  const workedDays = valuesByDay.filter((dayValues) =>
    Boolean(
      dayValues.normal ||
      dayValues.holiday ||
      dayValues.clockIn ||
      dayValues.clockOut,
    ),
  ).length;

  const recordedWeekKeys = new Set();
  valuesByDay.forEach((dayValues, index) => {
    if (!Object.keys(dayValues).length) {
      return;
    }

    const date = new Date(year, month, index + 1);
    const dayOfWeek = date.getDay();
    const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
    const monday = new Date(year, month, index + 1 + mondayOffset);
    recordedWeekKeys.add(
      createDateKey(
        monday.getFullYear(),
        monday.getMonth(),
        monday.getDate(),
      ),
    );
  });

  attendanceStatusFooter.innerHTML = `
    <span>주차수: <strong>${recordedWeekKeys.size}</strong></span>
    <span>근무일수: <strong>${workedDays}</strong></span>
    <span>기록일수: <strong>${recordedDays}</strong></span>
  `;
}

''' + render_calendar_anchor

text = replace_once(text, render_calendar_anchor, status_logic, "renderCalendar")
text += "\n/* v214 개인별 월간 근태 현황 */\n"

css_block = r'''
/* v214 개인별 월간 근태 현황 */
.attendance-status-nav-icon {
  font-size: 17px;
  font-weight: 900;
  letter-spacing: -0.12em;
}

.attendance-status-page {
  width: 100%;
  min-width: 0;
}

.attendance-status-card {
  width: 100%;
  min-width: 0;
  padding: 18px;
  border: 1px solid rgba(203, 213, 225, 0.92);
  border-radius: 22px;
  background: #fff;
  box-shadow: 0 14px 34px rgba(15, 23, 42, 0.07);
}

.attendance-status-report-title {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  margin: 2px 0 12px;
  color: #172033;
  text-align: center;
}

.attendance-status-report-title strong {
  font-size: clamp(20px, 4.8vw, 28px);
  font-weight: 900;
  letter-spacing: 0.02em;
}

.attendance-status-report-title span {
  font-size: 13px;
  font-weight: 700;
  color: #475569;
}

.attendance-status-toolbar {
  display: grid;
  grid-template-columns: 44px minmax(0, 1fr) 44px;
  align-items: center;
  gap: 8px;
  max-width: 360px;
  margin: 0 auto 14px;
}

.attendance-status-toolbar > strong {
  text-align: center;
  font-size: 18px;
  font-weight: 900;
}

.attendance-status-month-button {
  width: 44px;
  height: 40px;
  border: 1px solid #d9e0ea;
  border-radius: 12px;
  background: #f8fafc;
  color: #172033;
  font-size: 28px;
  line-height: 1;
}

.attendance-status-table-wrap {
  width: 100%;
  overflow-x: auto;
  overflow-y: hidden;
  border: 1px solid #475569;
  border-radius: 4px;
  background: #fff;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: thin;
}

.attendance-status-table {
  width: max-content;
  min-width: 1120px;
  border-collapse: collapse;
  table-layout: fixed;
  background: #fff;
  color: #1f2937;
  font-size: 11px;
  font-variant-numeric: tabular-nums;
}

.attendance-status-table th,
.attendance-status-table td {
  width: 31px;
  min-width: 31px;
  height: 27px;
  padding: 2px 1px;
  border-right: 1px solid #94a3b8;
  border-bottom: 1px solid #94a3b8;
  text-align: center;
  vertical-align: middle;
  white-space: nowrap;
}

.attendance-status-table thead th {
  height: 24px;
  background: #f8fafc;
  font-weight: 800;
}

.attendance-status-table .attendance-status-corner,
.attendance-status-table .attendance-status-row-label {
  position: sticky;
  left: 0;
  z-index: 3;
  width: 52px;
  min-width: 52px;
  background: #fff;
  font-weight: 800;
}

.attendance-status-table thead .attendance-status-corner {
  z-index: 5;
  background: #f8fafc;
}

.attendance-status-table .attendance-status-sum-head,
.attendance-status-table .attendance-status-total {
  position: sticky;
  left: 52px;
  z-index: 2;
  width: 48px;
  min-width: 48px;
  background: #fff;
  font-weight: 800;
}

.attendance-status-table thead .attendance-status-sum-head {
  z-index: 4;
  background: #f8fafc;
}

.attendance-status-table .is-saturday {
  color: #2563eb;
}

.attendance-status-table .is-sunday {
  color: #dc2626;
}

.attendance-status-table .is-outside {
  background: #f8fafc;
  color: #cbd5e1;
}

.attendance-status-table tr:last-child th,
.attendance-status-table tr:last-child td {
  border-bottom: 0;
}

.attendance-status-table th:last-child,
.attendance-status-table td:last-child {
  border-right: 0;
}

.attendance-status-footer {
  display: flex;
  flex-wrap: wrap;
  gap: 12px 34px;
  margin-top: 12px;
  padding: 0 4px;
  color: #334155;
  font-size: 13px;
  font-weight: 700;
}

.attendance-status-footer strong {
  margin-left: 4px;
  color: #111827;
}

@media (max-width: 620px) {
  .attendance-status-card {
    padding: 14px 10px 16px;
    border-radius: 18px;
  }

  .attendance-status-report-title strong {
    font-size: 22px;
  }

  .attendance-status-table {
    min-width: 1090px;
    font-size: 10px;
  }

  .attendance-status-table th,
  .attendance-status-table td {
    width: 30px;
    min-width: 30px;
    height: 26px;
  }

  .attendance-status-footer {
    gap: 8px 20px;
    font-size: 12px;
  }
}
'''

if MARKER not in style:
    style += "\n" + css_block

main_path.write_text(text, encoding="utf-8")
style_path.write_text(style, encoding="utf-8")

check = subprocess.run(
    ["node", "--check", str(main_path)],
    capture_output=True,
    text=True,
)
if check.returncode != 0:
    sys.stderr.write(check.stderr)
    sys.exit("node --check 실패: main.js 문법 오류가 있어 적용을 중단합니다.")

print("v214 근태현황 적용 완료")
print("- 메뉴: 근태관리 바로 아래 근태현황 추가")
print("- 개인별 월간 근태 현황 표 추가")
print("- 부서/사번/성명/본인확인 줄 없음")
print("- 근태관리 기록과 자동 연동")
print("- src/main.js, src/style.css만 변경")
