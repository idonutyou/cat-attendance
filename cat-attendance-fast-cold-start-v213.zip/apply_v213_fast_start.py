from pathlib import Path
import sys
import subprocess

target = Path("src/main.js")
if not target.exists():
    sys.exit(f"대상 파일을 찾을 수 없습니다: {target}")

text = target.read_text(encoding="utf-8")

if "function showCachedAppShellWhileCloudRestores()" in text:
    print("v213 빠른 시작 수정이 이미 적용되어 있습니다.")
    sys.exit(0)

show_app_shell = """function showAppShell() {
  authGate.hidden = true;
  authGate.setAttribute("aria-hidden", "true");
  appShell.hidden = false;
  appShell.classList.remove("auth-locked");
  appShell.setAttribute("aria-hidden", "false");
  document.documentElement.classList.remove("auth-gate-active");
  updateAccountPanel();
  render();
}
"""

cached_helper = show_app_shell + """
function showCachedAppShellWhileCloudRestores() {
  // 저장된 근태/급여 데이터는 이미 localStorage에서 읽혀 있으므로
  // Firebase 인증/Firestore 조회를 기다리지 않고 화면부터 보여줍니다.
  // 계정 패널은 실제 인증 복원이 끝난 뒤 showAppShell()에서 갱신합니다.
  authGate.hidden = true;
  authGate.setAttribute("aria-hidden", "true");
  appShell.hidden = false;
  appShell.classList.remove("auth-locked");
  appShell.setAttribute("aria-hidden", "false");
  document.documentElement.classList.remove("auth-gate-active");
  render();
}
"""

if show_app_shell not in text:
    sys.exit("안전 중단: showAppShell() 위치를 찾지 못했습니다. 현재 버전을 확인해 주세요.")

text = text.replace(show_app_shell, cached_helper, 1)

old_splash = """      if (
        authMode === "guest" ||
        (authMode === "google" && activeGoogleUser)
      ) {
        showAppShell();
      } else if (!authRedirectInProgress) {
        showAuthGate();
      }
"""

new_splash = """      if (
        authMode === "guest" ||
        (authMode === "google" && activeGoogleUser)
      ) {
        showAppShell();
      } else {
        const savedMode = localStorage.getItem(AUTH_MODE_KEY);
        const savedGoogleUid = localStorage.getItem(
          ACTIVE_GOOGLE_UID_KEY,
        );
        const canShowCachedShell =
          savedMode === "guest" ||
          (savedMode === "google" && Boolean(savedGoogleUid));

        if (canShowCachedShell) {
          showCachedAppShellWhileCloudRestores();
        } else if (!authRedirectInProgress) {
          showAuthGate();
        }
      }
"""

if old_splash not in text:
    sys.exit("안전 중단: 시작 화면 전환 코드를 찾지 못했습니다. 현재 버전을 확인해 주세요.")

text = text.replace(old_splash, new_splash, 1)
target.write_text(text, encoding="utf-8")

check = subprocess.run(
    ["node", "--check", str(target)],
    capture_output=True,
    text=True,
)
if check.returncode != 0:
    sys.stderr.write(check.stderr)
    sys.exit("node --check 실패: main.js 문법 오류가 있어 적용을 중단합니다.")

print("v213 빠른 시작 수정 적용 완료")
print("- src/main.js만 변경")
print("- 저장된 로컬 달력을 스플래시 직후 먼저 표시")
print("- Firebase/Firestore 동기화는 기존 코드 그대로 뒤에서 계속")
