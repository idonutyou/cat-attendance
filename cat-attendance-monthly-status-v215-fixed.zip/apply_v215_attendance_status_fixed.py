
from pathlib import Path
import sys
import subprocess

main_path = Path("src/main.js")
style_path = Path("src/style.css")

if not main_path.exists() or not style_path.exists():
    sys.exit("안전 중단: src/main.js 또는 src/style.css를 찾지 못했습니다.")

text = main_path.read_text(encoding="utf-8")
style = style_path.read_text(encoding="utf-8")

MARK = "v215 개인별 월간 근태 현황"
if MARK in text:
    print("v215 근태현황이 이미 적용되어 있습니다.")
    sys.exit(0)

def must_replace(src, old, new, name):
    if old not in src:
        sys.exit(f"안전 중단: {name} 위치를 찾지 못했습니다.")
    return src.replace(old, new, 1)

text = must_replace(
    text,
    'const APP_PAGE_TITLES = {\\n  attendance: "근태관리",\\n  salary: "급여내역",',
    'const APP_PAGE_TITLES = {\\n  attendance: "근태관리",\\n  status: "근태현황",\\n  salary: "급여내역",',
    "APP_PAGE_TITLES",
)

text = must_replace(
    text,
    'let currentAppPage = "attendance";\\n',
    'let currentAppPage = "attendance";\\nlet attendanceStatusMonth = new Date(currentMonth);\\n',
    "currentAppPage",
)

menu_anchor = '''          <button
            class="navigation-item active"
            type="button"
            data-app-navigation="attendance"
            aria-current="page"
          >
            <span class="navigation-icon">▦</span>
            <span>근태관리</span>
          </button>
'''
menu_insert = menu_anchor + '''          <button
            class="navigation-item"
            type="button"
            data-app-navigation="status"
          >
            <span class="navigation-icon attendance-status-nav-icon">표</span>
            <span>근태현황</span>
          </button>
'''
text = must_replace(text, menu_anchor, menu_insert, "근태관리 메뉴")

salary_anchor = '''      <section
        class="app-page"
        data-app-page="salary"
        aria-label="급여내역"
        hidden
      >'''
status_page = '''      <section
        class="app-page attendance-status-page"
        data-app-page="status"
        aria-label="근태현황"
        hidden
      >
        <section class="attendance-status-card">
          <div class="attendance-status-report-title">
            <strong>개인별 월간 근태 현황</strong>
            <span id="attendanceStatusPeriod"></span>
          </div>
          <div class="attendance-status-toolbar">
            <button id="attendanceStatusPreviousMonth" class="attendance-status-month-button" type="button" aria-label="이전 달">‹</button>
            <strong id="attendanceStatusMonthTitle"></strong>
            <button id="attendanceStatusNextMonth" class="attendance-status-month-button" type="button" aria-label="다음 달">›</button>
          </div>
          <div id="attendanceStatusTableWrap" class="attendance-status-table-wrap"></div>
          <div id="attendanceStatusFooter" class="attendance-status-footer"></div>
        </section>
      </section>

''' + salary_anchor
text = must_replace(text, salary_anchor, status_page, "급여내역 페이지")

dom_anchor = '''const appNavigationButtons = [
  ...document.querySelectorAll("[data-app-navigation]"),
];
'''
dom_insert = dom_anchor + '''const attendanceStatusPreviousMonth = document.querySelector("#attendanceStatusPreviousMonth");
const attendanceStatusNextMonth = document.querySelector("#attendanceStatusNextMonth");
const attendanceStatusMonthTitle = document.querySelector("#attendanceStatusMonthTitle");
const attendanceStatusPeriod = document.querySelector("#attendanceStatusPeriod");
const attendanceStatusTableWrap = document.querySelector("#attendanceStatusTableWrap");
const attendanceStatusFooter = document.querySelector("#attendanceStatusFooter");
'''
text = must_replace(text, dom_anchor, dom_insert, "DOM 참조")

listener_anchor = '''appNavigationButtons.forEach((button) => {
  button.addEventListener("click", () => {
    setAppPage(button.dataset.appNavigation);
  });
});
'''
listener_insert = listener_anchor + '''
attendanceStatusPreviousMonth?.addEventListener("click", () => {
  attendanceStatusMonth = new Date(
    attendanceStatusMonth.getFullYear(),
    attendanceStatusMonth.getMonth() - 1,
    1,
  );
  renderAttendanceStatus();
});

attendanceStatusNextMonth?.addEventListener("click", () => {
  attendanceStatusMonth = new Date(
    attendanceStatusMonth.getFullYear(),
    attendanceStatusMonth.getMonth() + 1,
    1,
  );
  renderAttendanceStatus();
});
'''
text = must_replace(text, listener_anchor, listener_insert, "근태현황 월 이동 이벤트")

page_anchor = '''  closeNavigationDrawer();
  closeSalaryYearPicker();
  closeAnnualLeaveYearPicker();
  if (pageId === "salary") {'''
page_insert = '''  closeNavigationDrawer();
  closeSalaryYearPicker();
  closeAnnualLeaveYearPicker();
  if (pageId === "status") {
    renderAttendanceStatus();
  }
  if (pageId === "salary") {'''
text = must_replace(text, page_anchor, page_insert, "setAppPage")

render_anchor = '''function render() {
  renderCalendar();
  syncWeeklyDateRangeInputs();'''
render_insert = '''function render() {
  renderCalendar();
  renderAttendanceStatus();
  syncWeeklyDateRangeInputs();'''
text = must_replace(text, render_anchor, render_insert, "render")

calendar_anchor = '''function renderCalendar() {
  renderCalendarWeekdayHeaders();'''

logic = '''/* v215 개인별 월간 근태 현황 */
const ATTENDANCE_STATUS_ROWS = [
  ["clockIn", "출근", false],
  ["clockOut", "퇴근", false],
  ["late", "지각", true],
  ["earlyLeave", "조퇴", true],
  ["outing", "외출", true],
  ["absence", "결근", true],
  ["normal", "정상", true],
  ["overtime1", "연장1", true],
  ["overtime2", "연장2", true],
  ["night", "심야", true],
  ["overnight", "철야", true],
  ["holiday", "휴일", true],
  ["shutdown", "휴업", false],
];

function getAttendanceStatusValues(workRecord) {
  const workType = getWorkType(workRecord);
  if (!workType) return {};

  switch (workType.id) {
    case "day":
      return { clockIn: "0800", clockOut: "1700", normal: 8 };
    case "dayOvertime":
      return { clockIn: "0800", clockOut: "2000", normal: 8, overtime2: 2.5 };
    case "night":
      return { clockIn: "2000", clockOut: "0500", normal: 8, night: 6 };
    case "nightOvertime":
      return { clockIn: "2000", clockOut: "0800", normal: 8, overtime1: 2, night: 7, overnight: 1 };
    case "dayHoliday":
      return { clockIn: "0800", clockOut: "1700", holiday: 8 };
    case "dayHolidayOvertime":
      return { clockIn: "0800", clockOut: "2000", overtime2: 2.5, holiday: 8 };
    case "nightHoliday":
      return { clockIn: "2000", clockOut: "0500", night: 6, holiday: 8 };
    case "nightHolidayOvertime":
      return { clockIn: "2000", clockOut: "0800", overtime1: 2, night: 6, overnight: 1, holiday: 8 };
    case "earlyLeave":
      return { earlyLeave: 4 };
    case "annualLeave":
      return { shutdown: "연차" };
    case "halfAnnualLeave":
      return { shutdown: "반차" };
    default:
      return {};
  }
}

function renderAttendanceStatus() {
  if (!attendanceStatusTableWrap || !attendanceStatusMonthTitle || !attendanceStatusPeriod || !attendanceStatusFooter) return;

  const year = attendanceStatusMonth.getFullYear();
  const month = attendanceStatusMonth.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthText = String(month + 1).padStart(2, "0");

  attendanceStatusMonthTitle.textContent = `${year}년 ${month + 1}월`;
  attendanceStatusPeriod.textContent = `( ${year}년 ${monthText}월 )`;

  const valuesByDay = Array.from({ length: 31 }, (_, index) => {
    const day = index + 1;
    if (day > daysInMonth) return {};
    return getAttendanceStatusValues(records[createDateKey(year, month, day)]);
  });

  const dayHeaders = Array.from({ length: 31 }, (_, index) => {
    const day = index + 1;
    return `<th class="${day > daysInMonth ? "is-outside" : ""}">${day}</th>`;
  }).join("");

  const weekdayHeaders = Array.from({ length: 31 }, (_, index) => {
    const day = index + 1;
    if (day > daysInMonth) return '<th class="is-outside"></th>';
    const weekday = new Date(year, month, day).getDay();
    const label = ["일", "월", "화", "수", "목", "금", "토"][weekday];
    const cls = weekday === 0 ? "is-sunday" : weekday === 6 ? "is-saturday" : "";
    return `<th class="${cls}">${label}</th>`;
  }).join("");

  const bodyRows = ATTENDANCE_STATUS_ROWS.map(([key, label, totalable]) => {
    const nums = valuesByDay.map((v) => v[key]).filter((v) => typeof v === "number");
    const total = totalable && nums.length ? nums.reduce((a, b) => a + b, 0) : "";
    const cells = valuesByDay.map((value, index) => {
      if (index + 1 > daysInMonth) return '<td class="is-outside"></td>';
      const cell = value[key];
      return `<td>${cell === undefined ? "" : escapeHtml(cell)}</td>`;
    }).join("");
    return `<tr><th class="attendance-status-row-label">${label}</th><td class="attendance-status-total">${total}</td>${cells}</tr>`;
  }).join("");

  attendanceStatusTableWrap.innerHTML = `
    <table class="attendance-status-table">
      <thead>
        <tr>
          <th rowspan="2" class="attendance-status-corner">구분</th>
          <th rowspan="2" class="attendance-status-sum-head">합계</th>
          ${dayHeaders}
        </tr>
        <tr>${weekdayHeaders}</tr>
      </thead>
      <tbody>${bodyRows}</tbody>
    </table>
  `;

  const recordedDays = valuesByDay.filter((v) => Object.keys(v).length > 0).length;
  attendanceStatusFooter.innerHTML = `<span>근무일수: <strong>${recordedDays}</strong></span>`;
}

''' + calendar_anchor

text = must_replace(text, calendar_anchor, logic, "renderCalendar")

style += '''

/* v215 개인별 월간 근태 현황 */
.attendance-status-nav-icon { font-size: 16px; font-weight: 900; }
.attendance-status-page { width: 100%; min-width: 0; }
.attendance-status-card {
  width: 100%; min-width: 0; padding: 18px;
  border: 1px solid #d7dee8; border-radius: 22px;
  background: #fff; box-shadow: 0 14px 34px rgba(15,23,42,.07);
}
.attendance-status-report-title {
  display: flex; flex-direction: column; align-items: center;
  gap: 3px; margin: 2px 0 12px; text-align: center;
}
.attendance-status-report-title strong { font-size: clamp(20px,4.8vw,28px); font-weight: 900; }
.attendance-status-report-title span { color:#475569; font-size:13px; font-weight:700; }
.attendance-status-toolbar {
  display:grid; grid-template-columns:44px minmax(0,1fr) 44px;
  align-items:center; gap:8px; max-width:360px; margin:0 auto 14px;
}
.attendance-status-toolbar > strong { text-align:center; font-size:18px; font-weight:900; }
.attendance-status-month-button {
  width:44px; height:40px; border:1px solid #d9e0ea; border-radius:12px;
  background:#f8fafc; color:#172033; font-size:28px;
}
.attendance-status-table-wrap {
  width:100%; overflow-x:auto; overflow-y:hidden;
  border:1px solid #475569; background:#fff; -webkit-overflow-scrolling:touch;
}
.attendance-status-table {
  width:max-content; min-width:1120px; border-collapse:collapse;
  table-layout:fixed; color:#1f2937; font-size:11px; font-variant-numeric:tabular-nums;
}
.attendance-status-table th,.attendance-status-table td {
  width:31px; min-width:31px; height:27px; padding:2px 1px;
  border-right:1px solid #94a3b8; border-bottom:1px solid #94a3b8;
  text-align:center; white-space:nowrap;
}
.attendance-status-table thead th { background:#f8fafc; font-weight:800; }
.attendance-status-table .attendance-status-corner,
.attendance-status-table .attendance-status-row-label {
  position:sticky; left:0; z-index:3; width:52px; min-width:52px;
  background:#fff; font-weight:800;
}
.attendance-status-table thead .attendance-status-corner { z-index:5; background:#f8fafc; }
.attendance-status-table .attendance-status-sum-head,
.attendance-status-table .attendance-status-total {
  position:sticky; left:52px; z-index:2; width:48px; min-width:48px;
  background:#fff; font-weight:800;
}
.attendance-status-table thead .attendance-status-sum-head { z-index:4; background:#f8fafc; }
.attendance-status-table .is-saturday { color:#2563eb; }
.attendance-status-table .is-sunday { color:#dc2626; }
.attendance-status-table .is-outside { background:#f8fafc; color:#cbd5e1; }
.attendance-status-footer { margin-top:12px; padding:0 4px; color:#334155; font-size:13px; font-weight:700; }

@media (max-width:620px) {
  .attendance-status-card { padding:14px 10px 16px; border-radius:18px; }
  .attendance-status-table { min-width:1090px; font-size:10px; }
  .attendance-status-table th,.attendance-status-table td { width:30px; min-width:30px; height:26px; }
}
'''

main_path.write_text(text, encoding="utf-8")
style_path.write_text(style, encoding="utf-8")

check = subprocess.run(["node", "--check", str(main_path)], capture_output=True, text=True)
if check.returncode != 0:
    sys.stderr.write(check.stderr)
    sys.exit("안전 중단: main.js 문법 검사 실패")

final_text = main_path.read_text(encoding="utf-8")
for required in [
    'data-app-navigation="status"',
    'data-app-page="status"',
    '개인별 월간 근태 현황',
    'function renderAttendanceStatus()',
]:
    if required not in final_text:
        sys.exit("안전 중단: 적용 검증 실패 - " + required)

print("v215 근태현황 적용 및 검증 완료")
print("- 메뉴 추가 확인")
print("- 근태현황 페이지 추가 확인")
print("- 월간 표 렌더 함수 확인")
print("- src/main.js / src/style.css만 변경")
