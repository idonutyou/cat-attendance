from pathlib import Path
import sys

target = Path("android-widget/app/src/main/java/com/cat/attendance/widget/WorkTypeActivity.java")
if not target.exists():
    sys.exit(f"대상 파일을 찾을 수 없습니다: {target}")

text = target.read_text(encoding="utf-8")

if "private void syncWidgetChangeToApp()" in text:
    print("v212 양방향 동기화 수정이 이미 적용되어 있습니다.")
    sys.exit(0)

needle = "        WidgetCloudSync.pushCurrentStateAsync(this);"
count = text.count(needle)
if count != 3:
    sys.exit(
        f"안전 중단: 예상한 동기화 호출 3개가 아니라 {count}개입니다. "
        "현재 파일이 예상 버전과 달라 자동 수정하지 않았습니다."
    )

text = text.replace(needle, "        syncWidgetChangeToApp();")

marker = "    private void updateWindowBounds() {"
if marker not in text:
    sys.exit("안전 중단: helper 삽입 위치를 찾지 못했습니다.")

helper = (
    "    private void syncWidgetChangeToApp() {\n"
    "        WidgetCloudSync.pushCurrentStateAsync(this);\n"
    "\n"
    "        // 새 설치에서 아직 Firebase bridge 정보가 저장되지 않은 경우에도\n"
    "        // 위젯에서 바꾼 근태를 CAT 앱에 조용히 전달합니다.\n"
    "        if (WidgetDataStore.getCloudBridgeCredentials(this) == null) {\n"
    "            WidgetAppBridge.deliverPendingToRunningAppSilently(this);\n"
    "        }\n"
    "    }\n"
    "\n"
)

text = text.replace(marker, helper + marker, 1)
target.write_text(text, encoding="utf-8")

print("v212 양방향 동기화 수정 적용 완료")
print("- WorkTypeActivity.java만 변경")
print("- 위젯 -> 앱 fallback 추가")
